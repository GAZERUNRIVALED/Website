// Filter karakter di halaman Gallery. Tanpa JS, semua kartu tetap tampil.
(function () {
  var chips = document.querySelectorAll('.chip');
  if (!chips.length) return;
  var cards = document.querySelectorAll('#grid .card');
  var count = document.getElementById('count');

  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      var filter = chip.getAttribute('data-filter');
      var shown = 0;
      chips.forEach(function (c) {
        var on = c === chip;
        c.classList.toggle('is-active', on);
        c.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      cards.forEach(function (card) {
        var show = filter === 'all' || card.getAttribute('data-character') === filter;
        card.hidden = !show;
        if (show) shown++;
      });
      if (count) count.textContent = shown;
    });
  });
})();
